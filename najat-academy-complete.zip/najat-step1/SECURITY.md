# Security Notes

- Authorization is enforced server-side; UI visibility is not a security boundary.
- Financial amounts are stored as integer minor units (BDT poisha).
- Passwords use bcrypt and are never stored in audit records.
- Sessions use signed HttpOnly cookies.
- Payment webhook requests require HMAC verification and idempotency references.
- Private file storage is represented by a provider-neutral abstraction. Production storage must be private and issue short-lived signed URLs.
- `SESSION_SECRET`, database credentials, storage credentials and payment secrets belong only in environment variables.
- Rate limiting in this starter uses process memory. For a multi-instance production deployment, replace it with a shared Redis/Upstash implementation.
