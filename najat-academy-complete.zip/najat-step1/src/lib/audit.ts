import {connectDB} from "./db"; import {AuditLog} from "./models/AuditLog";
export async function writeAudit(input:{actorId?:string,actorRole?:string,action:string,targetType?:string,targetId?:string,metadata?:Record<string,unknown>,ip?:string,userAgent?:string}){try{await connectDB();await AuditLog.create(input);}catch{ /* audit failure must not leak internals to users */ }}
