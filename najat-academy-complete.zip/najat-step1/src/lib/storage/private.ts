/** Private-storage abstraction. Replace the provider implementation with S3/R2/etc. */
export interface PrivateStorage { put(key:string, body:Buffer, contentType:string):Promise<void>; signedUrl(key:string, expiresSeconds:number):Promise<string>; }
export function assertPrivateStorageConfigured(){
 const provider=process.env.STORAGE_PROVIDER;
 if(!provider) throw new Error("PRIVATE_STORAGE_NOT_CONFIGURED");
 if(!process.env.STORAGE_BUCKET) throw new Error("STORAGE_BUCKET_NOT_CONFIGURED");
}
export function privateObjectPolicy(){return {public:false,expiresSeconds:300};}
