import {NextResponse} from 'next/server';
export function ok(data:unknown,status=200){return NextResponse.json(data,{status});}
export function fail(message:string,status=500){return NextResponse.json({message},{status});}
export function pageParams(url:string){const u=new URL(url);const page=Math.max(1,Number(u.searchParams.get('page')||1));const limit=Math.min(100,Math.max(1,Number(u.searchParams.get('limit')||20)));return {page,limit,skip:(page-1)*limit};}
