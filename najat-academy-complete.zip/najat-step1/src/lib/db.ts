import mongoose from "mongoose";
const uri=process.env.MONGODB_URI;
if(!uri) throw new Error("MONGODB_URI পরিবেশ ভেরিয়েবল সেট করা হয়নি।");
declare global { var __najatDb:{conn:typeof mongoose|null,promise:Promise<typeof mongoose>|null}|undefined; }
const cached=global.__najatDb ?? {conn:null,promise:null}; global.__najatDb=cached;
export async function connectDB(){if(cached.conn)return cached.conn;if(!cached.promise)cached.promise=mongoose.connect(uri);cached.conn=await cached.promise;return cached.conn;}
