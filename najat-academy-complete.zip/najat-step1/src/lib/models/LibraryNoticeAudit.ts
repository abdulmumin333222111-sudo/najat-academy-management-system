import {Schema,model,models,Types} from 'mongoose';
const L=new Schema({title:{type:String,required:true},description:String,category:String,courseIds:[{type:Types.ObjectId,ref:'Course',index:true}],storageKey:{type:String,required:true},mimeType:String,privateFile:{type:Boolean,default:true},active:{type:Boolean,default:true}},{timestamps:true});
export const DigitalLibrary=models.DigitalLibrary||model('DigitalLibrary',L);
const N=new Schema({title:{type:String,required:true},body:{type:String,required:true},audience:[{type:String,enum:['ALL','ADMIN','TEACHER','STUDENT','GUARDIAN']}],publishedAt:Date,active:{type:Boolean,default:true}},{timestamps:true});
export const Notice=models.Notice||model('Notice',N);
const A=new Schema({actorId:{type:Types.ObjectId,ref:'User',index:true},actorRole:String,action:{type:String,required:true,index:true},targetType:String,targetId:String,metadata:{type:Schema.Types.Mixed},ip:String,userAgent:String},{timestamps:true});A.index({createdAt:-1});
export const AuditLog=models.AuditLog||model('AuditLog',A);
