import {Schema,model,models,Types} from 'mongoose';
const S=new Schema({userId:{type:Types.ObjectId,ref:'User',required:true,unique:true,index:true},phone:String,childIds:[{type:Types.ObjectId,ref:'Student',index:true}]},{timestamps:true});
export const Guardian=models.Guardian||model('Guardian',S);
