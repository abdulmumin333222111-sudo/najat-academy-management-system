import {NextResponse} from "next/server"; import {rateLimit} from "@/lib/rate-limit";
export async function GET(req:Request){const ip=req.headers.get("x-forwarded-for")?.split(",")[0]??"unknown";const r=rateLimit("health:"+ip,60,60000);return NextResponse.json({allowed:r.allowed},{status:r.allowed?200:429})}
