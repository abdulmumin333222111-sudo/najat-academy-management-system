import {NextResponse} from "next/server"; import {clearSession} from "@/lib/security"; export async function POST(){await clearSession();return NextResponse.json({message:"লগআউট সম্পন্ন হয়েছে।"})}
