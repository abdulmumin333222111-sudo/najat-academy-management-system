# Najat Academy Management System

Najat Academy — Learn Quran, Build Character

বাংলা-first full-stack management application built with Next.js, TypeScript, MongoDB/Mongoose, Zod, bcrypt and signed HttpOnly sessions.

## Modules included
Public pages, authentication, password-reset foundation, RBAC, Student/Guardian/Teacher portals, Admin foundation, admissions, courses, batches, attendance, finance, payments/webhook foundation, exams/results, certificates/verification foundation, digital library metadata, notices, audit logging and security headers.

## Setup
1. Copy `.env.example` to `.env.local`.
2. Set `MONGODB_URI` and a random `SESSION_SECRET` (32+ characters).
3. Run `npm install`.
4. Run `npm run dev`.

## Verification
Run these commands locally. This repository does not claim they passed unless the command output says so:
`npm run lint`, `npm run typecheck`, `npm run test`, `npm run build`.

## Production integrations still require provider credentials
Payment merchant/API credentials and private cloud storage credentials are intentionally placeholders. Never commit them.

## Important deployment note
The included in-memory rate limiter is suitable for a single-process development environment only. A multi-instance deployment must use a shared rate-limit store.
